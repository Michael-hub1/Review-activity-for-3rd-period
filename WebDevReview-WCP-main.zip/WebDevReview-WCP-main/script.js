document.getElementById('changeTextButton').addEventListener('click', function() {
    document.getElementById('dynamicText').innerHTML = 'The text has been changed!';
});
